Queen of Spain
Font Haus
~~~~~~~~~~~~~~

Bilbo-Hand Bold v1.0
~~~~~~~~~~~~~~~~~~~

Hey! You've downloaded the font "Bilbo-Hand Bold"! 
To install, drop the file into the following directory:

c:\windows\fonts

To utilize the markings above the vowels, capitalize those vowels.  There are no other capitals in this set, as Bilbo's handwriting doesn't use them.

Regards,
Nancy Lorenz.
Queen of Spain Font Girl.
~~~~~~~~~~~~~~~~~~~~~~~~~